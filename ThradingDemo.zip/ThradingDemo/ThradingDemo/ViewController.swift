//
//  ViewController.swift
//  ThradingDemo
//
//  Created by MAC2 on 19/11/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit

let img = ["https://images.unsplash.com/photo-1475598322381-f1b499717dda?ixlib=rb-0.3.5&q=85&fm=jpg&crop=entropy&cs=srgb&dl=buzz-andersen-145254-unsplash.jpg&s=6d0e9c1fa82fafe6c0791e352e0361bb","https://images.unsplash.com/photo-1493087670264-2f7f5844b402?ixlib=rb-0.3.5&q=85&fm=jpg&crop=entropy&cs=srgb&dl=alex-246078-unsplash.jpg&s=2318fa0548616ec9079064efb87910b1","https://images.unsplash.com/photo-1503249023995-51b0f3778ccf?ixlib=rb-0.3.5&q=85&fm=jpg&crop=entropy&cs=srgb&dl=warren-wong-346736-unsplash.jpg&s=01f172e507098d947ff1d142d54ade2f","https://images.unsplash.com/photo-1536905491217-7e9b8c1e226e?ixlib=rb-0.3.5&q=85&fm=jpg&crop=entropy&cs=srgb&dl=anita-austvika-1057079-unsplash.jpg&s=1f4e75d78e06b70dacc89fda057b4f4b"]

class downloader
{
    class func downloadImage(url:String) -> UIImage!
    {
        var data = Data()
        do {
            data = try! Data(contentsOf: URL(string:url)!)
        } catch
        {
            return nil
        }
        return UIImage(data: data)
    }
}
class ViewController: UIViewController
{
    @IBOutlet weak var img1: UIImageView!
    @IBOutlet weak var img2: UIImageView!
    @IBOutlet weak var img3: UIImageView!
    @IBOutlet weak var img4: UIImageView!
    @IBOutlet weak var lbl1: UILabel!
    @IBOutlet var lbl: UIView!
    @IBOutlet weak var stepper: UIStepper!
    var queue = OperationQueue()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func btnOperationQueue(_ sender: Any)
    {
        queue = OperationQueue()
        //Operation1
        let operation1 = BlockOperation(block:
        {
            let pic1 = downloader.downloadImage(url: img[0])
            OperationQueue.main.addOperation({
                self.img1.image = pic1
            })
        })
        operation1.completionBlock = { print("Operation1 completed.. , cancelled:\(operation1.isCancelled)")
        }
        queue.addOperation(operation1)
        
        //Operation2
        let operation2 = BlockOperation(block:
        {
            let pic2 = downloader.downloadImage(url: img[1])
            OperationQueue.main.addOperation({
                self.img2.image = pic2
            })
        })
        //operation2.addDependency(operation1)
        operation2.completionBlock = { print("Operation2 completed.. , cancelled:\(operation2.isCancelled)")
        }
        queue.addOperation(operation2)
        
        //Operation3
        let operation3 = BlockOperation(block:
        {
            let pic3 = downloader.downloadImage(url: img[2])
            OperationQueue.main.addOperation({
                self.img3.image = pic3
            })
        })
        //operation3.addDependency(operation2)
        operation3.completionBlock = { print("Operation3 completed.. , cancelled:\(operation3.isCancelled)")
        }
        queue.addOperation(operation3)
        
        //Operation4
        let operation4 = BlockOperation(block:
        {
            let pic4 = downloader.downloadImage(url: img[3])
            OperationQueue.main.addOperation({
                self.img4.image = pic4
            })
        })
        //operation4.addDependency(operation3)
        operation4.completionBlock = { print("Operation4 completed.. , cancelled:\(operation4.isCancelled)")
        }
        queue.addOperation(operation4)
    }
    
    @IBAction func btnSerialQueue(_ sender: Any)
    {
        let serialQueue = DispatchQueue(label: "com.appcoda.imagesQueue", attributes:[])
        
        //Image 1
        serialQueue.async
        {
            let pic1 = downloader.downloadImage(url: img[0])
            DispatchQueue.main.async(execute: {
                self.img1.image = pic1
            })
        }
        
        //Image 2
        serialQueue.async
        {
            let pic2 = downloader.downloadImage(url: img[1])
            DispatchQueue.main.async(execute: {
                self.img2.image = pic2
            })
        }
        
        //Image 3
        serialQueue.async
        {
            let pic3 = downloader.downloadImage(url: img[2])
            DispatchQueue.main.async(execute: {
                self.img3.image = pic3
            })
        }
        
        //Image 4
        serialQueue.async
        {
            let pic4 = downloader.downloadImage(url: img[3])
            DispatchQueue.main.async(execute: {
                self.img4.image = pic4
            })
        }
    }
    
    @IBAction func stepperAction(_ sender: Any)
    {
        lbl1.text = String(Int(stepper.value))
    }
    
    @IBAction func btnCancel(_ sender: Any)
    {
        queue.cancelAllOperations()
    }
    
}

